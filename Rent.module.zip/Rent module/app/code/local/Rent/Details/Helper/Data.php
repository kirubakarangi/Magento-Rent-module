<?php
 
/**
 * Operations data helper
 *
 * @category   Rent
 * @package    Rent_Details
 */
class Rent_Details_Helper_Data extends Mage_Core_Helper_Abstract
{
 
}